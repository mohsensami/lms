'use client';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { formatPrice } from '@/lib/formatPrice';
import { cn } from '@/lib/utils';
import { GraduationCap } from 'lucide-react';
import { Star } from 'lucide-react';
import { ArrowUpDown, MoreHorizontal, Pencil } from 'lucide-react';
import Link from 'next/link';

export const columns = [
    {
        accessorKey: 'title',
        header: ({ column }) => {
            return (
                <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}>
                    نام دوره <ArrowUpDown className="ml-2 h-4 w-4" />
                </Button>
            );
        },
    },
    {
        accessorKey: 'price',
        header: ({ column }) => {
            return (
                <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}>
                    قیمت <ArrowUpDown className="ml-2 h-4 w-4" />
                </Button>
            );
        },
        cell: ({ row }) => {
            const price = parseFloat(row.getValue('price') || '0');
            const formatted = formatPrice(price);
            return <div>{formatted}</div>;
        },
    },
    {
        accessorKey: 'active',
        header: ({ column }) => {
            return (
                <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}>
                    وضعیت <ArrowUpDown className="ml-2 h-4 w-4" />
                </Button>
            );
        },
        cell: ({ row }) => {
            const active = row.getValue('active') || false;

            return (
                <Badge className={cn('bg-gray-500', active && 'bg-green-600')}>
                    {active ? 'منتشر شده' : 'منتشر نشده'}
                </Badge>
            );
        },
    },
    {
        id: 'actions',
        cell: ({ row }) => {
            const id = row.original._id;
            return (
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-4 w-8 p-0">
                            <span className="sr-only">منو</span>
                            <MoreHorizontal className="h-4 w-4" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                        <Link href={`/account/courses/${id}`}>
                            <DropdownMenuItem className="cursor-pointer">
                                <Pencil className="h-4 w-4 mr-2" />
                                ویرایش
                            </DropdownMenuItem>
                        </Link>
                        <Link href={`/account/courses/${id}/enrollments`}>
                            <DropdownMenuItem className="cursor-pointer">
                                <GraduationCap className="h-4 w-4 mr-2" />
                                مشاهده ثبت‌نام‌ها
                            </DropdownMenuItem>
                        </Link>
                        <Link href={`/account/courses/${id}/reviews`}>
                            <DropdownMenuItem className="cursor-pointer">
                                <Star className="h-4 w-4 mr-2 fill-primary" />
                                مشاهده نظرات
                            </DropdownMenuItem>
                        </Link>
                    </DropdownMenuContent>
                </DropdownMenu>
            );
        },
    },
];
