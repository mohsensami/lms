import { Badge } from '@/components/ui/badge';
import { BookOpen } from 'lucide-react';
import Image from 'next/image';
import EnrolledCourseCard from '../../component/enrolled-coursecard';
import { auth } from '@/auth';
import { redirect } from 'next/navigation';
import { getUserByEmail } from '@/queries/users';
import { getEnrollmentsForUser } from '@/queries/enrollments';
import Link from 'next/link';

async function EnrolledCourses() {
    const session = await auth();
    if (!session?.user) {
        redirect('/login');
    }

    const loggedInUser = await getUserByEmail(session?.user?.email);

    const enrollments = await getEnrollmentsForUser(loggedInUser?.id);
    // console.log(enrollments);

    return (
        <div className="grid sm:grid-cols-2 gap-6">
            {enrollments && enrollments.length > 0 ? (
                <>
                    {enrollments.map((enrollment) => {
                        const course = enrollment?.course;
                        const courseId = course ? (course._id ? course._id.toString() : course.id || null) : null;

                        return courseId ? (
                            // <Link key={enrollment?.id} href={`/courses/${courseId}/lesson`}>
                            <Link key={enrollment?.id} href={`/courses/${courseId}`}>
                                <EnrolledCourseCard enrollment={enrollment} />
                            </Link>
                        ) : (
                            <div key={enrollment?.id}>
                                <EnrolledCourseCard enrollment={enrollment} />
                            </div>
                        );
                    })}
                </>
            ) : (
                <div className="font-bold bg-red-400 text-white p-2 w-100">هنوز در هیچ دوره‌ای ثبت‌نام نکرده‌اید!</div>
            )}
        </div>
    );
}

export default EnrolledCourses;
